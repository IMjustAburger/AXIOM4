# AXIOM 2.0.0 — Source Audit

## Project target

- Minecraft Java Edition: **1.21.11**
- Java toolchain: **21**
- Fabric Loader: **0.19.4**
- Fabric API: **0.141.6+1.21.11**
- Fabric Loom remap plugin: **1.14.10**
- Gradle used by GitHub Actions: **9.2.1**

## Project inventory

- 62 Java source files under `src/main/java`.
- 29 module classes registered by `ModuleManager`.
- 1 JUnit test source with 10 test methods for the production `ChunkScoring` class.
- GitHub Actions workflow at `.github/workflows/build.yml`.

## Implemented in source (not yet runtime-verified)

- Module registration and categorized module manager.
- World scan queue with bounded per-tick processing, deduplication, chunk unload invalidation, and no worker-thread access to Minecraft chunk objects.
- Chunk anomaly scoring, storage-block signals, rare-ore signals, and bounded confidence scores.
- Chunk, terrain anomaly, tunnel, storage, block, ore, player, mob, and hole visualization modules.
- Base map, stash finder, new-chunk tracker, search engine, and tunnel analysis modules.
- GUI/HUD infrastructure and configuration persistence.
- Fabric client entrypoint and mixins for keyboard, mouse, camera, tick, GUI render, and chunk lifecycle events.

## Fixes applied in this repair pass

1. Aligned the Gradle mappings with the Mojang-mapped imports in the source.
2. Updated the build configuration for Minecraft 1.21.11 and current Fabric dependency coordinates.
3. Added a GitHub Actions build that provisions Java 21 and Gradle 9.2.1, runs unit tests and `build`, and uploads the remapped JAR only after success.
4. Updated the keyboard mixin to Minecraft 1.21.11's `keyPress(long, int, KeyEvent)` signature and read key/modifier values from `KeyEvent`.
5. Corrected the camera mixin setup parameter to `Level`.
6. Changed world scanning to process a bounded number of currently loaded chunks on the client thread rather than reading live chunks from a worker thread.
7. Fixed the first-tick queue reset that discarded the initial scan seeded by `WorldScanner.onEnable()`.
8. Added chunk-unload invalidation to the scanner/tunnel analysis path.
9. Updated world rendering to use the Fabric 1.21.11 buffered world-render API.
10. Kept test assertions against the actual production `ChunkScoring` code.

## Known limitations / items requiring a real client launch

- **No compiled JAR is included.** This environment does not have a local Gradle installation or the Gradle wrapper JAR, and it cannot download the Gradle/Minecraft dependencies. The first full compile is expected to happen in GitHub Actions.
- **No Minecraft launch test has been performed.** A successful Gradle build is not proof that every mixin injection applies in a live client.
- Some world ESP callbacks still read `Minecraft.level` or live entity state from a world-render drawing callback. Fabric's 1.21.11 world-render API separates extraction from drawing; live client-world access in drawing callbacks must be treated as a runtime compatibility risk and should be refactored to tick-time snapshots before calling this release fully verified.
- Storage ESP and Search Engine still perform relatively large block searches. They need profiling and incremental chunk processing before use on low-end systems or large radii.
- The world scanner is heuristic. Natural caves, abandoned mineshafts, generated structures, and player-made areas can resemble one another. A flagged chunk is only a lead for manual inspection, not proof of a base.
- The scan can only analyse chunks the client already has loaded. It does not access server-side hidden or unloaded world data.
- The ClickGUI's advanced setting editors (notably slider dragging and color editing) need an interaction test; do not assume every control is fully interactive merely because it is displayed.
- FreeLook and all mixin hooks require a live 1.21.11 launch test. The mixin descriptors were aligned to the 1.21.11 mappings available during this repair, but runtime application has not been proven here.

## Build status

**Not compiled in this environment.** Do not label this source package as a finished or tested release until the GitHub Actions workflow succeeds and the client launches successfully on Minecraft 1.21.11 with the matching Fabric Loader/API.
