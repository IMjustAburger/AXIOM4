#!/usr/bin/env bash
# Optional local wrapper bootstrap. GitHub Actions uses a provisioned Gradle
# installation and does not need gradle-wrapper.jar.
set -euo pipefail
GRADLE_VERSION="9.2.1"
if ! command -v gradle >/dev/null 2>&1; then
  echo "Gradle is not installed. Install Gradle ${GRADLE_VERSION} first, then run this script."
  echo "https://gradle.org/releases/"
  exit 1
fi
gradle wrapper --gradle-version "${GRADLE_VERSION}" --distribution-type bin
if [[ ! -f gradle/wrapper/gradle-wrapper.jar ]]; then
  echo "Wrapper JAR was not generated." >&2
  exit 1
fi
echo "Gradle wrapper created. Run ./gradlew clean test build"
