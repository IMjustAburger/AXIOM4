# AXIOM 2.0.0 — Build & Install

## Target

- Minecraft Java Edition **1.21.11**
- Java **21**
- Fabric Loader **0.19.4** (or a compatible newer 1.21.11 loader)
- Fabric API **0.141.6+1.21.11**
- Fabric Loom remapping plugin **1.14.10**
- Gradle **9.2.1**

The source imports Mojang-mapped Minecraft names, so the build uses
`loom.officialMojangMappings()` rather than Yarn mappings.

## Build locally

If you have Gradle 9.2.1 installed:

```bash
gradle wrapper --gradle-version 9.2.1 --distribution-type bin
./gradlew --no-daemon clean test build
```

The compiled mod is written to `build/libs/axiom-2.0.0.jar`.

On Windows, run `gradlew.bat` instead of `./gradlew`.

## Build on GitHub Actions (no local Gradle installation needed)

1. Create a GitHub repository and upload the **contents** of this folder (so `.github/workflows/build.yml` is at the repository root).
2. Open the repository's **Actions** tab.
3. Select **Build AXIOM** and choose **Run workflow**, or push a commit to `main` / `master`.
4. Wait for the workflow to finish. A green check means Gradle compilation and JUnit tests succeeded.
5. Open the successful workflow run and download the artifact named `axiom-2.0.0-minecraft-1.21.11`.
6. The artifact contains `axiom-2.0.0.jar`.

The workflow installs Java and Gradle itself, so it does not need the missing
`gradle-wrapper.jar` from the original ZIP. A JAR is published only after
`clean test build` succeeds.

## Install

1. Install Minecraft Java 1.21.11.
2. Install Fabric Loader for Minecraft 1.21.11.
3. Put `axiom-2.0.0.jar` and the matching Fabric API JAR in `.minecraft/mods/`.
4. Launch the Fabric profile. Press **INSERT** to open the AXIOM GUI.

Settings are saved to `.minecraft/axiom/config.json`.

## Important verification note

This source package has been statically reviewed and updated, but it has not
been compiled or launched in this environment. Treat the GitHub Actions run
as the first authoritative compile/test result. A successful Gradle build does
not by itself prove that every Mixin injection works at runtime; launch the
exact Minecraft version and inspect `latest.log` before treating the release
as tested.
