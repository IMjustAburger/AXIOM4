package dev.axiom;

import dev.axiom.core.world.ChunkScoring;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/** Tests the exact production scoring code used by ChunkAnalyzer. */
class ChunkScoringTest {

    @Test
    @DisplayName("Empty input produces no signals")
    void emptyInputProducesNoSignals() {
        assertTrue(ChunkScoring.score(new ChunkScoring.Stats(0, 0, 0, 0, 0)).isEmpty());
    }

    @Test
    @DisplayName("Air ratio below excavation threshold is not flagged as excavation")
    void naturalAirRatioDoesNotTriggerExcavation() {
        List<ChunkScoring.Signal> signals = ChunkScoring.score(
                new ChunkScoring.Stats(1000, 80, 0, 0, 0));
        assertFalse(has(signals, ChunkScoring.Kind.EXCAVATION));
    }

    @Test
    @DisplayName("Air ratio above excavation threshold triggers excavation")
    void highAirRatioTriggersExcavation() {
        List<ChunkScoring.Signal> signals = ChunkScoring.score(
                new ChunkScoring.Stats(1000, 400, 0, 0, 0));
        assertTrue(has(signals, ChunkScoring.Kind.EXCAVATION));
    }

    @Test
    @DisplayName("Four or more storage blocks produce a storage cluster")
    void storageClusterThreshold() {
        List<ChunkScoring.Signal> signals = ChunkScoring.score(
                new ChunkScoring.Stats(1000, 0, 4, 4, 0));
        assertTrue(has(signals, ChunkScoring.Kind.STORAGE_CLUSTER));
    }

    @Test
    @DisplayName("Fewer than four storage blocks do not produce a storage cluster")
    void belowStorageClusterThreshold() {
        List<ChunkScoring.Signal> signals = ChunkScoring.score(
                new ChunkScoring.Stats(1000, 0, 3, 3, 0));
        assertFalse(has(signals, ChunkScoring.Kind.STORAGE_CLUSTER));
    }

    @Test
    @DisplayName("Crafted blocks are identified when no storage cluster exists")
    void craftedBlocksSignal() {
        List<ChunkScoring.Signal> signals = ChunkScoring.score(
                new ChunkScoring.Stats(1000, 0, 3, 0, 0));
        assertTrue(has(signals, ChunkScoring.Kind.RARE_BLOCKS));
    }

    @Test
    @DisplayName("Three rare ores produce an ore-density signal")
    void rareOreSignal() {
        List<ChunkScoring.Signal> signals = ChunkScoring.score(
                new ChunkScoring.Stats(1000, 0, 0, 0, 3));
        assertTrue(has(signals, ChunkScoring.Kind.HIGH_ORE_DENSITY));
    }

    @Test
    @DisplayName("Three independent signals add a composite signal")
    void compositeSignal() {
        List<ChunkScoring.Signal> signals = ChunkScoring.score(
                new ChunkScoring.Stats(1000, 400, 8, 4, 3));
        assertTrue(has(signals, ChunkScoring.Kind.EXCAVATION));
        assertTrue(has(signals, ChunkScoring.Kind.STORAGE_CLUSTER));
        assertTrue(has(signals, ChunkScoring.Kind.HIGH_ORE_DENSITY));
        assertTrue(has(signals, ChunkScoring.Kind.COMPOSITE));
    }

    @Test
    @DisplayName("Every returned confidence value is between zero and one")
    void confidenceValuesAreBounded() {
        List<ChunkScoring.Signal> signals = ChunkScoring.score(
                new ChunkScoring.Stats(1000, 900, 20, 8, 50));
        assertFalse(signals.isEmpty());
        for (ChunkScoring.Signal signal : signals) {
            assertTrue(signal.confidence() >= 0.0 && signal.confidence() <= 1.0,
                    () -> signal.kind() + " confidence was " + signal.confidence());
        }
    }

    @Test
    @DisplayName("Counts above total are safely clamped")
    void countsAreClamped() {
        List<ChunkScoring.Signal> signals = ChunkScoring.score(
                new ChunkScoring.Stats(10, 100, 100, 100, 100));
        assertFalse(signals.isEmpty());
        for (ChunkScoring.Signal signal : signals) {
            assertTrue(Double.isFinite(signal.confidence()));
            assertTrue(signal.confidence() >= 0.0 && signal.confidence() <= 1.0);
        }
    }

    private static boolean has(List<ChunkScoring.Signal> signals, ChunkScoring.Kind kind) {
        return signals.stream().anyMatch(signal -> signal.kind() == kind);
    }
}
