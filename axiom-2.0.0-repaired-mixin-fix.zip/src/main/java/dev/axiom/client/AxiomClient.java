package dev.axiom.client;

import dev.axiom.core.config.ConfigManager;
import dev.axiom.core.event.EventBus;
import dev.axiom.core.event.EventHandler;
import dev.axiom.core.event.events.EventKey;
import dev.axiom.core.module.ModuleManager;
import dev.axiom.gui.click.ClickGUI;
import dev.axiom.gui.hud.HudRenderer;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import dev.axiom.core.event.events.EventRender3D;
import net.minecraft.client.Minecraft;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AxiomClient implements ClientModInitializer {

    public static final String MOD_ID   = "axiom";
    public static final String MOD_NAME = "AXIOM";
    public static final Logger LOGGER   = LoggerFactory.getLogger(MOD_NAME);

    private static AxiomClient INSTANCE;
    private static EventBus    eventBus;

    @Override
    public void onInitializeClient() {
        INSTANCE = this;
        LOGGER.info("AXIOM World Intelligence System initializing...");

        eventBus = EventBus.getInstance();
        ModuleManager.getInstance().loadAll();
        ConfigManager.getInstance().load();

        // Always-on renderers and input handlers
        new HudRenderer();
        eventBus.subscribe(this);   // for ClickGUI open key

        // 1.21.11 uses Fabric's world-render API instead of the old
        // GameRenderer mixin/PoseStack drawing path.
        WorldRenderEvents.AFTER_ENTITIES.register(context -> {
            float partialTick = Minecraft.getInstance().getDeltaTracker()
                    .getGameTimeDeltaPartialTick(false);
            eventBus.post(new EventRender3D(context.matrices(), context.consumers(), partialTick));
        });

        LOGGER.info("AXIOM initialized — {} modules loaded.",
                ModuleManager.getInstance().getAll().size());
    }

    /** Open ClickGUI on INSERT key press. */
    @EventHandler
    public void onKey(EventKey e) {
        if (e.getKey() == GLFW.GLFW_KEY_INSERT && e.getAction() == GLFW.GLFW_PRESS) {
            Minecraft mc = Minecraft.getInstance();
            if (mc.screen == null) {
                mc.setScreen(new ClickGUI());
            }
        }
    }

    public static AxiomClient getInstance()  { return INSTANCE; }
    public static EventBus   getEventBus()   { return EventBus.getInstance(); }
}
