package dev.axiom.mixin;

import dev.axiom.client.AxiomClient;
import dev.axiom.core.event.events.EventChunkLoad;
import dev.axiom.core.event.events.EventChunkUnload;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.ChunkPos;
import net.minecraft.world.level.chunk.LevelChunk;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientLevel.class)
public class MixinClientLevel {

    @Inject(method = "onChunkLoaded", at = @At("TAIL"))
    private void axiom$onChunkLoaded(ChunkPos chunkPos, CallbackInfo ci) {
        ClientLevel self = (ClientLevel) (Object) this;
        if (!self.hasChunk(chunkPos.x, chunkPos.z)) return;
        LevelChunk chunk = self.getChunk(chunkPos.x, chunkPos.z);
        if (chunk != null) {
            AxiomClient.getEventBus().post(new EventChunkLoad(chunk));
        }
    }

    @Inject(method = "unload", at = @At("HEAD"))
    private void axiom$onChunkUnload(LevelChunk chunk, CallbackInfo ci) {
        if (chunk != null) {
            AxiomClient.getEventBus().post(new EventChunkUnload(chunk.getPos()));
        }
    }
}
