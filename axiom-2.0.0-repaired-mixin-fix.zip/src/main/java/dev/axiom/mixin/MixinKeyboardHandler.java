package dev.axiom.mixin;

import dev.axiom.client.AxiomClient;
import dev.axiom.core.event.events.EventKey;
import dev.axiom.core.module.ModuleManager;
import net.minecraft.client.KeyboardHandler;
import net.minecraft.client.input.KeyEvent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(KeyboardHandler.class)
public class MixinKeyboardHandler {

    @Inject(method = "keyPress", at = @At("HEAD"), cancellable = true)
    private void onKeyPress(long windowPtr, int action, KeyEvent input, CallbackInfo ci) {
        int key = input.key();
        int mods = input.modifiers();

        // Fire EventKey
        EventKey e = new EventKey(key, action, mods);
        AxiomClient.getEventBus().post(e);
        if (e.isCancelled()) { ci.cancel(); return; }

        // Dispatch to module keybinds
        if (action == org.lwjgl.glfw.GLFW.GLFW_PRESS) {
            ModuleManager.getInstance().onKey(key);
        }
    }
}
