package dev.axiom.core.world;

import java.util.ArrayList;
import java.util.List;

/**
 * Pure, Minecraft-independent scoring rules used by {@link ChunkAnalyzer}.
 * Keeping the scoring separate makes the production rules directly unit-testable.
 */
public final class ChunkScoring {
    private static final double EXCAVATION_AIR_RATIO = 0.25;

    private ChunkScoring() {}

    public enum Kind {
        EXCAVATION,
        TUNNEL,
        STORAGE_CLUSTER,
        RARE_BLOCKS,
        HIGH_ORE_DENSITY,
        COMPOSITE
    }

    public record Stats(
            int totalBlocks,
            int airBlocks,
            int craftedBlocks,
            int storageBlocks,
            int rareOreBlocks
    ) {}

    public record Signal(Kind kind, double confidence, String detail) {}

    public static List<Signal> score(Stats stats) {
        if (stats == null || stats.totalBlocks() <= 0) return List.of();

        int total = stats.totalBlocks();
        int air = clampCount(stats.airBlocks(), total);
        int crafted = clampCount(stats.craftedBlocks(), total);
        int storage = clampCount(stats.storageBlocks(), total);
        int rareOres = clampCount(stats.rareOreBlocks(), total);

        double airRatio = (double) air / total;
        List<Signal> results = new ArrayList<>();

        if (airRatio > EXCAVATION_AIR_RATIO) {
            double confidence = Math.min(1.0,
                    (airRatio - EXCAVATION_AIR_RATIO) / 0.30 * 0.8 + 0.3);
            if (crafted > 0) confidence = Math.min(1.0, confidence + 0.15);
            results.add(new Signal(Kind.EXCAVATION, confidence,
                    String.format("%.0f%% subterranean air ratio, %d crafted blocks", airRatio * 100, crafted)));
        }

        if (airRatio > 0.12 && airRatio < 0.28 && crafted < 5) {
            double confidence = 0.35 + (airRatio - 0.12) / 0.16 * 0.35;
            results.add(new Signal(Kind.TUNNEL, confidence,
                    String.format("%.0f%% subterranean air, tunnel-like distribution", airRatio * 100)));
        }

        if (storage >= 4) {
            double confidence = Math.min(0.95, 0.40 + storage * 0.07);
            results.add(new Signal(Kind.STORAGE_CLUSTER, confidence,
                    storage + " storage containers detected"));
        }

        if (crafted >= 3 && storage < 4) {
            double confidence = Math.min(0.90, 0.30 + crafted * 0.08);
            results.add(new Signal(Kind.RARE_BLOCKS, confidence,
                    crafted + " crafted/rare blocks in chunk"));
        }

        if (rareOres >= 3) {
            double confidence = Math.min(0.75, 0.30 + rareOres * 0.08);
            results.add(new Signal(Kind.HIGH_ORE_DENSITY, confidence,
                    rareOres + " rare ore blocks"));
        }

        if (results.size() >= 3) {
            double maxConfidence = results.stream()
                    .mapToDouble(Signal::confidence)
                    .max()
                    .orElse(0.0);
            results.add(new Signal(Kind.COMPOSITE,
                    Math.min(0.98, maxConfidence + 0.10),
                    results.size() + " overlapping anomaly types"));
        }

        return List.copyOf(results);
    }

    private static int clampCount(int value, int maximum) {
        return Math.max(0, Math.min(value, maximum));
    }
}
