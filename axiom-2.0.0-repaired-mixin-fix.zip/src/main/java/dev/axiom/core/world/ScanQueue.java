package dev.axiom.core.world;

import dev.axiom.client.AxiomClient;
import net.minecraft.client.Minecraft;
import net.minecraft.core.ChunkPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.chunk.LevelChunk;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;

/**
 * Main-thread chunk scan queue. Minecraft world/chunk objects are deliberately
 * never read from a worker thread. Work is capped at four chunks per client tick.
 */
public final class ScanQueue {

    private static final ScanQueue INSTANCE = new ScanQueue();
    private static final int MAX_PENDING = 2048;
    private int chunksPerTick = 2;

    public static ScanQueue getInstance() { return INSTANCE; }

    private final ArrayDeque<ChunkPos> pending = new ArrayDeque<>();
    private final Set<Long> queued = new HashSet<>();
    private final Set<Long> scanned = new HashSet<>();
    private final ConcurrentHashMap<Long, List<ChunkAnomaly>> results = new ConcurrentHashMap<>();

    private boolean running;
    private Level activeLevel;
    private int minY = -60;
    private int maxY = 60;
    private double confidenceThreshold = 0.55;
    private Consumer<List<ChunkAnomaly>> onNewAnomalies;

    private ScanQueue() {}

    public void start() {
        running = true;
    }

    /** Sets a small, bounded amount of work per client tick. */
    public void setChunksPerTick(int value) {
        this.chunksPerTick = Math.max(1, Math.min(4, value));
    }

    public void stop() {
        running = false;
        clear();
    }

    public void enqueue(ChunkPos pos) {
        if (!running || pos == null) return;
        long key = pos.toLong();
        if (scanned.contains(key) || !queued.add(key)) return;
        if (pending.size() >= MAX_PENDING) {
            ChunkPos dropped = pending.pollFirst();
            if (dropped != null) queued.remove(dropped.toLong());
        }
        pending.addLast(pos);
    }

    public void invalidate(ChunkPos pos) {
        if (pos == null) return;
        long key = pos.toLong();
        scanned.remove(key);
        queued.remove(key);
        pending.removeIf(candidate -> candidate.toLong() == key);
        results.remove(key);
    }

    public void clear() {
        pending.clear();
        queued.clear();
        results.clear();
        scanned.clear();
        activeLevel = null;
    }

    public List<ChunkAnomaly> getAnomalies(ChunkPos pos) {
        return results.getOrDefault(pos.toLong(), Collections.emptyList());
    }

    public Collection<List<ChunkAnomaly>> getAllAnomalies() {
        return List.copyOf(results.values());
    }

    public void setMinY(int y) { this.minY = y; }
    public void setMaxY(int y) { this.maxY = y; }
    public void setConfidenceThreshold(double threshold) {
        this.confidenceThreshold = Math.max(0.0, Math.min(1.0, threshold));
    }
    public void setOnNewAnomalies(Consumer<List<ChunkAnomaly>> callback) {
        this.onNewAnomalies = callback;
    }

    /** Must be called from the client tick thread. */
    public void processPending(Minecraft minecraft) {
        if (!running || minecraft == null) return;

        if (minecraft.level == null) {
            activeLevel = null;
            clear();
            return;
        }

        if (activeLevel == null) {
            // Preserve chunks queued during WorldScanner.onEnable().
            activeLevel = minecraft.level;
        } else if (activeLevel != minecraft.level) {
            // A world/server change invalidates all results from the old level.
            clear();
            activeLevel = minecraft.level;
        }

        for (int processed = 0; processed < chunksPerTick; processed++) {
            ChunkPos pos = pending.pollFirst();
            if (pos == null) return;

            long key = pos.toLong();
            queued.remove(key);
            if (scanned.contains(key)) continue;

            try {
                // hasChunk checks the client cache first; getChunk is only
                // called for a chunk that is already loaded, so the scanner
                // never requests new terrain from the server.
                if (!minecraft.level.hasChunk(pos.x, pos.z)) continue;
                LevelChunk chunk = minecraft.level.getChunk(pos.x, pos.z);
                if (chunk == null) continue;

                List<ChunkAnomaly> anomalies = ChunkAnalyzer.analyze(chunk, minY, maxY);
                List<ChunkAnomaly> filtered = anomalies.stream()
                        .filter(anomaly -> anomaly.confidence >= confidenceThreshold)
                        .toList();

                scanned.add(key);
                if (filtered.isEmpty()) {
                    results.remove(key);
                } else {
                    results.put(key, filtered);
                    if (onNewAnomalies != null) {
                        try {
                            onNewAnomalies.accept(filtered);
                        } catch (RuntimeException callbackError) {
                            AxiomClient.LOGGER.warn("Scan callback failed", callbackError);
                        }
                    }
                }
            } catch (RuntimeException error) {
                AxiomClient.LOGGER.warn("Could not scan chunk {},{}", pos.x, pos.z, error);
            }
        }
    }
}
