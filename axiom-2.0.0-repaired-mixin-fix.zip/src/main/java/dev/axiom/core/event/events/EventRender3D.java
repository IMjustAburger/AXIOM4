package dev.axiom.core.event.events;

import com.mojang.blaze3d.vertex.PoseStack;
import dev.axiom.core.event.Event;
import net.minecraft.client.renderer.MultiBufferSource;

/** World-render context exposed to feature modules for the current frame. */
public class EventRender3D extends Event {
    private final PoseStack poseStack;
    private final MultiBufferSource consumers;
    private final float partialTick;

    public EventRender3D(PoseStack poseStack, MultiBufferSource consumers, float partialTick) {
        this.poseStack = poseStack;
        this.consumers = consumers;
        this.partialTick = partialTick;
    }

    public PoseStack getPoseStack() { return poseStack; }
    public MultiBufferSource getConsumers() { return consumers; }
    public float getPartialTick() { return partialTick; }
}
