package dev.axiom.core.event.events;
import dev.axiom.core.event.Event;
import net.minecraft.core.ChunkPos;
public class EventChunkUnload extends Event {
    private final ChunkPos pos;
    public EventChunkUnload(ChunkPos p){ pos = p; }
    public ChunkPos getPos(){ return pos; }
}
