package dev.axiom.core.event;
import java.lang.annotation.*;
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface EventHandler {
    Priority priority() default Priority.NORMAL;
}
