package dev.axiom.core.event;

/**
 * Base class for all AXIOM events.
 * Events that can be cancelled implement {@link ICancellable} and manage
 * their own cancelled state.
 */
public abstract class Event {
    // No shared cancelled field — ICancellable implementors carry their own.
}
