package dev.axiom.core.util;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.world.phys.Vec3;

import java.util.List;

public final class RenderUtil {
    private static final Minecraft mc = Minecraft.getInstance();

    private RenderUtil() {}

    // ── 2D ────────────────────────────────────────────────────────────────────
    public static void drawText(GuiGraphics gg, String text, int x, int y, int color, boolean shadow) {
        if (shadow) gg.drawString(mc.font, text, x, y, color);
        else gg.drawString(mc.font, text, x, y, color, false);
    }

    public static void drawRect(GuiGraphics gg, int x, int y, int w, int h, int color) {
        gg.fill(x, y, x + w, y + h, color);
    }

    public static void drawBorder(GuiGraphics gg, int x, int y, int w, int h, int color) {
        gg.fill(x, y, x + w, y + 1, color);
        gg.fill(x, y + h - 1, x + w, y + h, color);
        gg.fill(x, y, x + 1, y + h, color);
        gg.fill(x + w - 1, y, x + w, y + h, color);
    }

    // ── 3D: use Minecraft's 1.21.11 RenderTypes and the world's buffer source. ─
    // Coordinates passed by callers are camera-relative, as required by the
    // Fabric WorldRenderContext consumer API. Minecraft flushes these buffers
    // as part of the current world-render pass.
    public static void drawBox(PoseStack matrices, MultiBufferSource consumers,
                               double x1, double y1, double z1,
                               double x2, double y2, double z2, int argb) {
        VertexConsumer out = consumers.getBuffer(RenderTypes.lines());
        PoseStack.Pose pose = matrices.last();
        float ax = (float) x1, ay = (float) y1, az = (float) z1;
        float bx = (float) x2, by = (float) y2, bz = (float) z2;

        // Four vertical edges.
        line(out, pose, ax, ay, az, bx, ay, az, argb);
        line(out, pose, bx, ay, az, bx, by, az, argb);
        line(out, pose, bx, by, az, ax, by, az, argb);
        line(out, pose, ax, by, az, ax, ay, az, argb);
        line(out, pose, ax, ay, bz, bx, ay, bz, argb);
        line(out, pose, bx, ay, bz, bx, by, bz, argb);
        line(out, pose, bx, by, bz, ax, by, bz, argb);
        line(out, pose, ax, by, bz, ax, ay, bz, argb);

        // Four horizontal connecting edges.
        line(out, pose, ax, ay, az, ax, ay, bz, argb);
        line(out, pose, bx, ay, az, bx, ay, bz, argb);
        line(out, pose, bx, by, az, bx, by, bz, argb);
        line(out, pose, ax, by, az, ax, by, bz, argb);
    }

    public static void drawFilledBox(PoseStack matrices, MultiBufferSource consumers,
                                     double x1, double y1, double z1,
                                     double x2, double y2, double z2, int argb) {
        VertexConsumer out = consumers.getBuffer(RenderTypes.debugFilledBox());
        PoseStack.Pose pose = matrices.last();
        float ax = (float) x1, ay = (float) y1, az = (float) z1;
        float bx = (float) x2, by = (float) y2, bz = (float) z2;

        // Six quads. Winding is consistent on each face.
        quad(out, pose, ax, ay, az, bx, ay, az, bx, ay, bz, ax, ay, bz, argb);
        quad(out, pose, ax, by, az, ax, by, bz, bx, by, bz, bx, by, az, argb);
        quad(out, pose, ax, ay, az, ax, by, az, bx, by, az, bx, ay, az, argb);
        quad(out, pose, bx, ay, bz, bx, by, bz, ax, by, bz, ax, ay, bz, argb);
        quad(out, pose, ax, ay, bz, ax, by, bz, ax, by, az, ax, ay, az, argb);
        quad(out, pose, bx, ay, az, bx, by, az, bx, by, bz, bx, ay, bz, argb);
    }

    /** Draws a connected polyline whose points are camera-relative. */
    public static void drawLines(PoseStack matrices, MultiBufferSource consumers,
                                 List<Vec3> points, int argb) {
        if (points == null || points.size() < 2) return;
        VertexConsumer out = consumers.getBuffer(RenderTypes.lines());
        PoseStack.Pose pose = matrices.last();
        Vec3 previous = points.getFirst();
        for (int i = 1; i < points.size(); i++) {
            Vec3 current = points.get(i);
            line(out, pose,
                    (float) previous.x, (float) previous.y, (float) previous.z,
                    (float) current.x, (float) current.y, (float) current.z,
                    argb);
            previous = current;
        }
    }

    private static void line(VertexConsumer out, PoseStack.Pose pose,
                             float x1, float y1, float z1,
                             float x2, float y2, float z2, int argb) {
        out.addVertex(pose, x1, y1, z1).setColor(argb);
        out.addVertex(pose, x2, y2, z2).setColor(argb);
    }

    private static void quad(VertexConsumer out, PoseStack.Pose pose,
                             float x1, float y1, float z1,
                             float x2, float y2, float z2,
                             float x3, float y3, float z3,
                             float x4, float y4, float z4, int argb) {
        out.addVertex(pose, x1, y1, z1).setColor(argb);
        out.addVertex(pose, x2, y2, z2).setColor(argb);
        out.addVertex(pose, x3, y3, z3).setColor(argb);
        out.addVertex(pose, x4, y4, z4).setColor(argb);
    }

    /** Projects a world-space point using Minecraft's own 1.21.11 projector. */
    public static float[] worldToScreen(Vec3 world) {
        if (mc.level == null || mc.player == null || world == null) return null;
        Vec3 projected = mc.gameRenderer.projectPointToScreen(world);
        if (projected == null || !projected.isFinite()) return null;
        int screenWidth = mc.getWindow().getGuiScaledWidth();
        int screenHeight = mc.getWindow().getGuiScaledHeight();
        // The engine projector returns normalized screen coordinates around
        // the viewport center; convert them to scaled GUI coordinates.
        float sx = (float) (screenWidth * (0.5 + projected.x));
        float sy = (float) (screenHeight * (0.5 - projected.y));
        if (sx < -screenWidth || sx > screenWidth * 2.0f
                || sy < -screenHeight || sy > screenHeight * 2.0f) return null;
        return new float[] { sx, sy };
    }

    public static int withAlpha(int argb, int alpha) {
        return (argb & 0x00FFFFFF) | (alpha << 24);
    }

    public static int lerpColor(int c1, int c2, float t) {
        float amount = Math.max(0.0f, Math.min(1.0f, t));
        int a1 = (c1 >>> 24) & 0xFF, r1 = (c1 >>> 16) & 0xFF;
        int g1 = (c1 >>> 8) & 0xFF, b1 = c1 & 0xFF;
        int a2 = (c2 >>> 24) & 0xFF, r2 = (c2 >>> 16) & 0xFF;
        int g2 = (c2 >>> 8) & 0xFF, b2 = c2 & 0xFF;
        int a = Math.round(a1 + amount * (a2 - a1));
        int r = Math.round(r1 + amount * (r2 - r1));
        int g = Math.round(g1 + amount * (g2 - g1));
        int b = Math.round(b1 + amount * (b2 - b1));
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    public static int confidenceColor(double confidence) {
        if (confidence >= 0.80) return 0xCCFF3333;
        if (confidence >= 0.60) return 0xCCFF8C00;
        if (confidence >= 0.40) return 0xCCFFD700;
        return 0xCC44FF44;
    }
}
