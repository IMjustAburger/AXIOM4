package dev.axiom.core.util;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import java.util.Set;
public class BlockUtil {
    private static final Minecraft mc = Minecraft.getInstance();
    public static final Set<Block> NATURAL_BLOCKS = Set.of(
        Blocks.STONE,Blocks.DEEPSLATE,Blocks.DIRT,Blocks.GRAVEL,Blocks.SAND,
        Blocks.WATER,Blocks.LAVA,Blocks.BEDROCK,Blocks.GRASS_BLOCK,Blocks.TUFF,
        Blocks.CALCITE,Blocks.DIORITE,Blocks.GRANITE,Blocks.ANDESITE,Blocks.CLAY,
        Blocks.IRON_ORE,Blocks.GOLD_ORE,Blocks.DIAMOND_ORE,Blocks.COAL_ORE,
        Blocks.COPPER_ORE,Blocks.LAPIS_ORE,Blocks.REDSTONE_ORE,Blocks.EMERALD_ORE,
        Blocks.DEEPSLATE_IRON_ORE,Blocks.DEEPSLATE_GOLD_ORE,Blocks.DEEPSLATE_DIAMOND_ORE,
        Blocks.DEEPSLATE_COAL_ORE,Blocks.DEEPSLATE_COPPER_ORE,Blocks.DEEPSLATE_LAPIS_ORE,
        Blocks.DEEPSLATE_REDSTONE_ORE,Blocks.DEEPSLATE_EMERALD_ORE,
        Blocks.CAVE_AIR,Blocks.AIR,Blocks.VOID_AIR
    );
    public static boolean isNatural(Block b){ return NATURAL_BLOCKS.contains(b); }
    public static boolean isAir(BlockState s){ return s.isAir(); }
    public static BlockState getState(BlockPos p){
        Level lvl = mc.level; if(lvl==null) return Blocks.AIR.defaultBlockState();
        return lvl.getBlockState(p);
    }
    public static boolean isBlastResistant(Block b){
        return b == Blocks.BEDROCK || b == Blocks.OBSIDIAN ||
               b == Blocks.CRYING_OBSIDIAN || b == Blocks.REINFORCED_DEEPSLATE;
    }
}
