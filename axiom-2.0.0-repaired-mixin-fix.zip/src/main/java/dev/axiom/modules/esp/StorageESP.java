package dev.axiom.modules.esp;

import dev.axiom.core.config.Setting;
import dev.axiom.core.event.EventHandler;
import dev.axiom.core.event.events.EventRender3D;
import dev.axiom.core.module.ModuleBase;
import dev.axiom.core.module.ModuleCategory;
import dev.axiom.core.util.RenderUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.ShulkerBoxBlock;
import net.minecraft.world.phys.Vec3;
import java.util.ArrayList;
import java.util.List;

public class StorageESP extends ModuleBase {

    private final Setting.ColorSetting   chestColor   = new Setting.ColorSetting("Chest Color",   "Chest/trapped chest",  0xCCFFD700);
    private final Setting.ColorSetting   barrelColor  = new Setting.ColorSetting("Barrel Color",  "Barrel containers",    0xCCCD853F);
    private final Setting.ColorSetting   shulkerColor = new Setting.ColorSetting("Shulker Color", "Shulker boxes",        0xCCFF69B4);
    private final Setting.IntSetting     radius       = new Setting.IntSetting("Radius", "Scan radius around player", 64, 16, 256);
    private final Setting.BooleanSetting filled       = new Setting.BooleanSetting("Filled", "Draw filled boxes", true);

    private final List<BlockPos> chests  = new ArrayList<>();
    private final List<BlockPos> barrels = new ArrayList<>();
    private final List<BlockPos> shulkers= new ArrayList<>();
    private int tick = 0;

    public StorageESP() {
        super("Storage ESP", "Highlights all storage containers", ModuleCategory.ESP);
        registerSetting(chestColor);
        registerSetting(barrelColor);
        registerSetting(shulkerColor);
        registerSetting(radius);
        registerSetting(filled);
    }

    @Override protected void onEnable()  { chests.clear(); barrels.clear(); shulkers.clear(); }
    @Override protected void onDisable() { chests.clear(); barrels.clear(); shulkers.clear(); }

    @EventHandler
    public void onRender3D(EventRender3D e) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;
        if (++tick >= 10) { tick = 0; scan(mc); }

        var cam = mc.gameRenderer.getMainCamera().getPosition();
        renderList(e, chests,   chestColor.getEffectiveColor(),   cam);
        renderList(e, barrels,  barrelColor.getEffectiveColor(),  cam);
        renderList(e, shulkers, shulkerColor.getEffectiveColor(), cam);
    }

    private void renderList(EventRender3D e, List<BlockPos> list, int col, Vec3 cam) {
        for (BlockPos bp : list) {
            double ox = bp.getX() - cam.x, oy = bp.getY() - cam.y, oz = bp.getZ() - cam.z;
            if (filled.getValue())
                RenderUtil.drawFilledBox(e.getPoseStack(), e.getConsumers(), ox, oy, oz, ox + 1, oy + 1, oz + 1, col & 0x44FFFFFF);
            RenderUtil.drawBox(e.getPoseStack(), e.getConsumers(), ox, oy, oz, ox + 1, oy + 1, oz + 1, col);
        }
    }

    private void scan(Minecraft mc) {
        chests.clear(); barrels.clear(); shulkers.clear();
        Level level  = mc.level;
        BlockPos center = mc.player.blockPosition();
        int r = radius.getValue();
        for (int x = center.getX()-r; x <= center.getX()+r; x++)
        for (int y = -64; y <= 100; y++)
        for (int z = center.getZ()-r; z <= center.getZ()+r; z++) {
            BlockPos bp = new BlockPos(x, y, z);
            Block b = level.getBlockState(bp).getBlock();
            if (b == Blocks.CHEST || b == Blocks.TRAPPED_CHEST) chests.add(bp);
            else if (b == Blocks.BARREL) barrels.add(bp);
            else if (b instanceof ShulkerBoxBlock) shulkers.add(bp);
        }
    }
}
