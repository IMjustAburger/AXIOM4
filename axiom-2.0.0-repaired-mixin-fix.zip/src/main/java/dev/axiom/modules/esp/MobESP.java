package dev.axiom.modules.esp;

import dev.axiom.core.config.Setting;
import dev.axiom.core.event.EventHandler;
import dev.axiom.core.event.events.EventRender3D;
import dev.axiom.core.module.ModuleBase;
import dev.axiom.core.module.ModuleCategory;
import dev.axiom.core.util.RenderUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.phys.AABB;

public class MobESP extends ModuleBase {

    private final Setting.ColorSetting   hostileColor = new Setting.ColorSetting("Hostile Color", "Color for hostile mobs", 0xCCFF4444);
    private final Setting.ColorSetting   passiveColor = new Setting.ColorSetting("Passive Color", "Color for passive mobs", 0xCC44FF44);
    private final Setting.BooleanSetting showHostile  = new Setting.BooleanSetting("Hostile", "Show hostile mobs", true);
    private final Setting.BooleanSetting showPassive  = new Setting.BooleanSetting("Passive", "Show passive mobs", false);
    private final Setting.IntSetting     range        = new Setting.IntSetting("Range", "Max render range", 64, 16, 256);

    public MobESP() {
        super("Mob ESP", "Draws boxes around mobs", ModuleCategory.ESP);
        registerSetting(hostileColor);
        registerSetting(passiveColor);
        registerSetting(showHostile);
        registerSetting(showPassive);
        registerSetting(range);
    }

    @Override protected void onEnable()  {}
    @Override protected void onDisable() {}

    @EventHandler
    public void onRender3D(EventRender3D e) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;
        var cam  = mc.gameRenderer.getMainCamera().getPosition();
        double maxR = range.getValue();

        for (var entity : mc.level.entitiesForRendering()) {
            if (!(entity instanceof Mob mob)) continue;
            if (mob.distanceTo(mc.player) > maxR) continue;
            boolean hostile = mob instanceof Monster;
            if (hostile  && !showHostile.getValue()) continue;
            if (!hostile && !showPassive.getValue()) continue;

            AABB bb = mob.getBoundingBox();
            double ox = -cam.x, oy = -cam.y, oz = -cam.z;
            int col = hostile ? hostileColor.getEffectiveColor() : passiveColor.getEffectiveColor();
            RenderUtil.drawBox(e.getPoseStack(), e.getConsumers(),
                bb.minX + ox, bb.minY + oy, bb.minZ + oz,
                bb.maxX + ox, bb.maxY + oy, bb.maxZ + oz, col);
        }
    }
}
