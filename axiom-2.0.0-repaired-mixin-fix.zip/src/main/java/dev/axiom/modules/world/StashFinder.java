package dev.axiom.modules.world;

import dev.axiom.core.config.Setting;
import dev.axiom.core.event.EventHandler;
import dev.axiom.core.event.events.EventChunkLoad;
import dev.axiom.core.module.ModuleBase;
import dev.axiom.core.module.ModuleCategory;
import net.minecraft.core.BlockPos;
import net.minecraft.core.ChunkPos;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.chunk.LevelChunk;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class StashFinder extends ModuleBase {

    private final Setting.IntSetting minStorage =
        new Setting.IntSetting("Min Containers","Minimum containers to flag a stash", 3, 1, 32);
    private final Setting.EnumSetting<Setting.Sensitivity> sensitivity =
        new Setting.EnumSetting<>("Sensitivity","Detection sensitivity",
            Setting.Sensitivity.MEDIUM, Setting.Sensitivity.class);

    private final Map<Long, StashInfo> stashes = new ConcurrentHashMap<>();

    public StashFinder() {
        super("Stash Finder", "Locates hidden storage clusters in terrain", ModuleCategory.WORLD);
        registerSetting(minStorage);
        registerSetting(sensitivity);
    }

    @Override protected void onEnable()  { stashes.clear(); }
    @Override protected void onDisable() { stashes.clear(); }

    @EventHandler
    public void onChunkLoad(EventChunkLoad e) {
        LevelChunk chunk = e.getChunk();
        ChunkPos cpos    = chunk.getPos();
        List<BlockPos> containers = new ArrayList<>();
        for (int x = cpos.getMinBlockX(); x <= cpos.getMaxBlockX(); x++) {
            for (int y = -64; y <= 100; y++) {
                for (int z = cpos.getMinBlockZ(); z <= cpos.getMaxBlockZ(); z++) {
                    BlockPos bp = new BlockPos(x, y, z);
                    var b = chunk.getBlockState(bp).getBlock();
                    if (b == Blocks.CHEST || b == Blocks.TRAPPED_CHEST ||
                        b == Blocks.BARREL || b.getClass().getSimpleName().contains("ShulkerBox")) {
                        containers.add(bp);
                    }
                }
            }
        }
        if (containers.size() >= minStorage.getValue()) {
            double conf = Math.min(0.98, 0.35 + containers.size() * 0.08);
            stashes.put(cpos.toLong(), new StashInfo(cpos, containers, conf));
        }
    }

    public Collection<StashInfo> getStashes() { return stashes.values(); }

    public record StashInfo(ChunkPos pos, List<BlockPos> containers, double confidence) {
        public BlockPos centroid() {
            int sx=0, sy=0, sz=0;
            for (BlockPos p : containers) { sx+=p.getX(); sy+=p.getY(); sz+=p.getZ(); }
            int n = containers.size();
            return new BlockPos(sx/n, sy/n, sz/n);
        }
    }
}
