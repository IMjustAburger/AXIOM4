package dev.axiom.modules.world;

import dev.axiom.core.config.Setting;
import dev.axiom.core.event.EventHandler;
import dev.axiom.core.event.events.EventChunkLoad;
import dev.axiom.core.event.events.EventChunkUnload;
import dev.axiom.core.module.ModuleBase;
import dev.axiom.core.module.ModuleCategory;
import net.minecraft.core.BlockPos;
import net.minecraft.core.ChunkPos;
import net.minecraft.world.level.chunk.LevelChunk;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class TunnelAnalyzer extends ModuleBase {

    private final Setting.IntSetting    scanY     = new Setting.IntSetting("Scan Y Level","Y level for tunnel detection",12,-64,64);
    private final Setting.IntSetting    minLength = new Setting.IntSetting("Min Tunnel Length","Minimum straight air run",8,4,64);
    private final Setting.EnumSetting<Setting.Sensitivity> sensitivity =
        new Setting.EnumSetting<>("Sensitivity","",Setting.Sensitivity.MEDIUM,Setting.Sensitivity.class);

    private final Map<Long, List<TunnelSegment>> tunnels = new ConcurrentHashMap<>();

    public TunnelAnalyzer() {
        super("Tunnel Analyzer", "Detects artificial tunnel networks", ModuleCategory.WORLD);
        registerSetting(scanY);
        registerSetting(minLength);
        registerSetting(sensitivity);
    }

    @Override protected void onEnable()  { tunnels.clear(); }
    @Override protected void onDisable() { tunnels.clear(); }

    @EventHandler
    public void onChunkLoad(EventChunkLoad e) {
        LevelChunk chunk = e.getChunk();
        ChunkPos cpos    = chunk.getPos();
        int y = scanY.getValue();
        int min = switch (sensitivity.getValue()) {
            case LOW -> minLength.getValue() + 4;
            case MEDIUM -> minLength.getValue();
            case HIGH -> Math.max(4, minLength.getValue() - 2);
            case VERY_HIGH -> Math.max(3, minLength.getValue() - 4);
        };

        List<TunnelSegment> segs = new ArrayList<>();

        // Scan X-axis runs
        for (int z = cpos.getMinBlockZ(); z <= cpos.getMaxBlockZ(); z++) {
            int runStart = -1, runLen = 0;
            for (int x = cpos.getMinBlockX(); x <= cpos.getMaxBlockX(); x++) {
                BlockPos bp = new BlockPos(x, y, z);
                boolean air = chunk.getBlockState(bp).isAir();
                if (air) {
                    if (runStart < 0) { runStart = x; runLen = 1; }
                    else runLen++;
                } else {
                    if (runLen >= min)
                        segs.add(new TunnelSegment(new BlockPos(runStart,y,z), new BlockPos(x-1,y,z), runLen, false));
                    runStart = -1; runLen = 0;
                }
            }
            if (runLen >= min)
                segs.add(new TunnelSegment(new BlockPos(runStart,y,z), new BlockPos(cpos.getMaxBlockX(),y,z), runLen, false));
        }

        // Scan Z-axis runs
        for (int x = cpos.getMinBlockX(); x <= cpos.getMaxBlockX(); x++) {
            int runStart = -1, runLen = 0;
            for (int z = cpos.getMinBlockZ(); z <= cpos.getMaxBlockZ(); z++) {
                BlockPos bp = new BlockPos(x, y, z);
                boolean air = chunk.getBlockState(bp).isAir();
                if (air) {
                    if (runStart < 0) { runStart = z; runLen = 1; }
                    else runLen++;
                } else {
                    if (runLen >= min)
                        segs.add(new TunnelSegment(new BlockPos(x,y,runStart), new BlockPos(x,y,z-1), runLen, true));
                    runStart = -1; runLen = 0;
                }
            }
            if (runLen >= min)
                segs.add(new TunnelSegment(new BlockPos(x,y,runStart), new BlockPos(x,y,cpos.getMaxBlockZ()), runLen, true));
        }

        if (segs.isEmpty()) tunnels.remove(cpos.toLong());
        else tunnels.put(cpos.toLong(), List.copyOf(segs));
    }

    @EventHandler
    public void onChunkUnload(EventChunkUnload event) {
        tunnels.remove(event.getPos().toLong());
    }

    public Collection<List<TunnelSegment>> getTunnels() { return List.copyOf(tunnels.values()); }

    public record TunnelSegment(BlockPos start, BlockPos end, int length, boolean zAxis) {}
}
