package dev.axiom.modules.movement;

import dev.axiom.core.config.Setting;
import dev.axiom.core.event.EventHandler;
import dev.axiom.core.event.events.EventTick;
import dev.axiom.core.module.ModuleBase;
import dev.axiom.core.module.ModuleCategory;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;

public class Sprint extends ModuleBase {

    private final Setting.BooleanSetting omniSprint =
        new Setting.BooleanSetting("Omni-Sprint", "Sprint in all directions, not just forward", true);

    public Sprint() {
        super("Sprint", "Automatically sprints without holding the sprint key", ModuleCategory.MOVEMENT);
        registerSetting(omniSprint);
    }

    @Override protected void onEnable()  {}
    @Override protected void onDisable() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) mc.player.setSprinting(false);
    }

    @EventHandler
    public void onTick(EventTick e) {
        if (e.getPhase() != EventTick.Phase.PRE) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        if (mc.player.isInWater() || mc.player.isInLava()) return;

        // LocalPlayer.input is a net.minecraft.client.player.Input in 1.21.x
        LocalPlayer lp = (LocalPlayer) mc.player;
        boolean forward  = lp.input.forwardImpulse != 0;
        boolean strafe   = lp.input.leftImpulse    != 0;
        boolean moving   = forward || strafe;

        if (!moving) { mc.player.setSprinting(false); return; }

        boolean canSprint = mc.player.getFoodData().getFoodLevel() > 6
            || mc.player.getAbilities().mayfly;

        if (canSprint) {
            if (omniSprint.getValue()) mc.player.setSprinting(true);
            else if (forward)          mc.player.setSprinting(true);
        }
    }
}
