package dev.axiom.modules.utility;

import dev.axiom.core.config.Setting;
import dev.axiom.core.event.EventHandler;
import dev.axiom.core.event.events.EventKey;
import dev.axiom.core.module.ModuleBase;
import dev.axiom.core.module.ModuleCategory;
import net.minecraft.client.Minecraft;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.ItemStack;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class InventorySorter extends ModuleBase {

    private final Setting.IntSetting sortKey =
        new Setting.IntSetting("Sort Key",
            "Press this key (while in inventory) to sort",
            GLFW.GLFW_KEY_R, 0, 400);

    public InventorySorter() {
        super("Inventory Sorter", "Sorts inventory by item type on keypress", ModuleCategory.UTILITY);
        registerSetting(sortKey);
    }

    @Override protected void onEnable()  {}
    @Override protected void onDisable() {}

    @EventHandler
    public void onKey(EventKey e) {
        if (e.getKey() != sortKey.getValue() || e.getAction() != GLFW.GLFW_PRESS) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.screen == null) return;
        sortInventory(mc);
    }

    private void sortInventory(Minecraft mc) {
        Inventory inv = mc.player.getInventory();
        // Collect non-hotbar items (slots 9–35)
        List<ItemStack> items = new ArrayList<>();
        for (int i = 9; i < 36; i++) {
            ItemStack s = inv.getItem(i).copy();
            if (!s.isEmpty()) items.add(s);
            inv.setItem(i, ItemStack.EMPTY);
        }
        items.sort(Comparator.comparing(s ->
            BuiltInRegistries.ITEM.getKey(s.getItem()).toString()));
        for (int i = 0; i < items.size() && i < 27; i++) {
            inv.setItem(9 + i, items.get(i));
        }
    }
}
