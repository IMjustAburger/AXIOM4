package dev.axiom.modules.combat;

import dev.axiom.core.config.Setting;
import dev.axiom.core.event.EventHandler;
import dev.axiom.core.event.events.EventTick;
import dev.axiom.core.module.ModuleBase;
import dev.axiom.core.module.ModuleCategory;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

public class Surround extends ModuleBase {

    private final Setting.BooleanSetting center = new Setting.BooleanSetting("Center", "Snap player to block center", true);
    private final Setting.BooleanSetting burrow = new Setting.BooleanSetting("Burrow",  "Place block below feet",      false);

    public Surround() {
        super("Surround", "Places obsidian surround around player", ModuleCategory.COMBAT);
        registerSetting(center);
        registerSetting(burrow);
    }

    @Override protected void onEnable()  {}
    @Override protected void onDisable() {}

    @EventHandler
    public void onTick(EventTick e) {
        if (e.getPhase() != EventTick.Phase.PRE) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;
        if (!(mc.player.getMainHandItem().getItem() instanceof BlockItem)) return;

        if (center.getValue()) {
            double cx = Math.floor(mc.player.getX()) + 0.5;
            double cz = Math.floor(mc.player.getZ()) + 0.5;
            mc.player.setPos(cx, mc.player.getY(), cz);
        }

        BlockPos feet = mc.player.blockPosition();
        BlockPos[] positions = {
            feet.north(), feet.south(), feet.east(), feet.west()
        };

        for (BlockPos pos : positions) {
            if (!mc.level.getBlockState(pos).isAir()) continue;
            BlockPos support = pos.below();
            if (mc.level.getBlockState(support).isAir()) continue;
            BlockHitResult hit = new BlockHitResult(
                Vec3.atCenterOf(support).add(0, 0.5, 0), Direction.UP, support, false);
            mc.gameMode.useItemOn(mc.player, InteractionHand.MAIN_HAND, hit);
        }

        if (burrow.getValue()) {
            BlockPos below = feet.below();
            if (mc.level.getBlockState(below).isAir()) {
                BlockPos support = below.below();
                if (!mc.level.getBlockState(support).isAir()) {
                    BlockHitResult hit = new BlockHitResult(
                        Vec3.atCenterOf(support).add(0, 0.5, 0), Direction.UP, support, false);
                    mc.gameMode.useItemOn(mc.player, InteractionHand.MAIN_HAND, hit);
                }
            }
        }
    }
}
