package dev.axiom.modules.combat;

import dev.axiom.core.event.EventHandler;
import dev.axiom.core.event.events.EventTick;
import dev.axiom.core.module.ModuleBase;
import dev.axiom.core.module.ModuleCategory;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

public class AutoTotem extends ModuleBase {

    public AutoTotem() {
        super("Auto Totem", "Keeps a totem in offhand automatically", ModuleCategory.COMBAT);
    }

    @Override protected void onEnable()  {}
    @Override protected void onDisable() {}

    @EventHandler
    public void onTick(EventTick e) {
        if (e.getPhase() != EventTick.Phase.PRE) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;

        // Offhand slot = 40 in the full inventory, slot 45 in the container
        ItemStack offhand = mc.player.getOffhandItem();
        if (offhand.getItem() == Items.TOTEM_OF_UNDYING) return;

        Inventory inv = mc.player.getInventory();
        int menuId = mc.player.containerMenu.containerId;

        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack stack = inv.getItem(i);
            if (stack.getItem() != Items.TOTEM_OF_UNDYING) continue;
            // Slot mapping: main hand 0-8 → container 36-44; hotbar same, rest 9-35 → 9-35
            int containerSlot = (i < 9) ? i + 36 : i;
            // Pick up totem, place in offhand (container slot 45), put remainder back
            mc.gameMode.handleInventoryMouseClick(menuId, containerSlot, 0, ClickType.PICKUP, mc.player);
            mc.gameMode.handleInventoryMouseClick(menuId, 45,           0, ClickType.PICKUP, mc.player);
            mc.gameMode.handleInventoryMouseClick(menuId, containerSlot, 0, ClickType.PICKUP, mc.player);
            break;
        }
    }
}
